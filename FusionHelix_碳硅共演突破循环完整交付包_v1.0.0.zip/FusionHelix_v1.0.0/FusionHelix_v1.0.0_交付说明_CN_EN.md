# FusionHelix v1.0.0 交付说明 / Delivery Guide

## 中文

FusionHelix 是碳基-硅基共同适应、复合能力消融、相变收据和权利边界运行时。

它把“融合”严格区分为：

- **辅助/增强**：性能提升，但联合新能力尚未被匹配消融证明；
- **共同适应**：碳基侧和硅基侧都在同一任务中发生可观察变化；
- **复合能力**：碳基单独、硅基单独均不能在匹配条件下完成，而联合系统成功；
- **相变**：复合能力、现实结果、独立复核及适用的身份、隐私、福利、可逆、价值和未来边界全部闭合。

### 快速运行

```bash
python fusionhelix.py new data/samples/program_input.json --out outputs/my_program.json
python fusionhelix.py event outputs/my_program.json data/samples/event_input.json --out outputs/my_program_v2.json
python fusionhelix.py audit data/samples/speech_neuroprosthesis_breakthrough.json
python fusionhelix.py phase-receipt data/samples/speech_neuroprosthesis_breakthrough.json --out outputs/phase.json
python fusionhelix.py decouple data/samples/organoid_welfare_blocked.json --out outputs/decoupling.json
python fusionhelix.py compare data/samples/speech_neuroprosthesis_breakthrough.json data/samples/wearable_lockin_open.json --out outputs/comparison.json
```

### 原地接入现有旗舰

```bash
python integration/install_into_existing_flagship.py /path/to/existing-flagship
```

安装器会写入 `modules/fusionhelix/`、保存安装前Git HEAD、建立本地Tag和安装收据；不会自动Push，也不会创建新仓库。

### 固定边界

- 不生成融合总分或人的价值分；
- 不声称机器、类器官或复合系统具有现象意识；
- 不公开原始神经数据、生物数据、捐赠者身份或私人自我报告；
- 活体基质在来源、福利不确定性、刺激上限、终止计划和独立伦理复核缺失时进入 `HALT_AND_REPAIR`；
- FB5身份/谱系改变保持研究级高风险，本系统不授权部署；
- 本软件不是医疗设备、伦理审批或实验操作授权。

## English

FusionHelix is a carbon-silicon co-adaptation, composite-capability ablation, phase-transition receipt and rights-boundary runtime.

A fusion claim requires matched carbon-alone, silicon-alone and joint tests, independent review, real-world outcome and closure of the applicable non-compensable gates.

The installer targets `modules/fusionhelix/` in an existing flagship. It never pushes or creates a repository automatically.

Fixed boundaries: no aggregate fusion/human-value score; phenomenal consciousness remains `NOT_ESTABLISHED`; raw neural and biological data are excluded from public export; living-substrate escalation is blocked when welfare, termination or ethics review remains open; the runtime is not a medical device or authorization for irreversible intervention.
