# Composite Capability Ablation Protocol / 复合能力消融协议

Test under matched constraints:
1. carbon alone,
2. silicon alone,
3. joint system,
4. sham/control,
5. independent observer,
6. hidden-assistance and data-leakage checks.
