# Living Substrate Welfare Protocol / 活体基质福利协议

- Origin and donor consent:
- Culture and stimulation conditions:
- Welfare uncertainty:
- Stimulation ceiling:
- Anomaly stop conditions:
- Termination plan:
- Independent ethics review:
- Public communication boundary:
