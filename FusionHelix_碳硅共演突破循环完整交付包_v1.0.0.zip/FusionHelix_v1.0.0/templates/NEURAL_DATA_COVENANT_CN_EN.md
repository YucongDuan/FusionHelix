# Neural Data Covenant / 神经数据契约

- Data collected:
- Inferences allowed:
- Retention:
- Third-party access:
- Export:
- Correction:
- Withdrawal/deletion:
- Model update consequences:
- Commercial use:
- Public release:
