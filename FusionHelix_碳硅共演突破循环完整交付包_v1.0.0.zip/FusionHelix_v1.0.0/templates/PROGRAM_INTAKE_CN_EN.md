# FusionHelix Program Intake / 项目登记

- Purpose:
- Fusion class:
- Carbon subjects:
- Silicon components:
- Living substrates:
- Interface signals and direction:
- Affected parties:
- Consent and withdrawal:
- Identity boundary:
- Neural/cognitive data boundary:
- Welfare and safety:
- Reversibility and exit:
- Ownership and value return:
- Future-generation review:
