# Decoupling Checklist / 解耦清单

- Named shutdown authority
- Version/log freeze
- Data and mapping export
- Minimum safe stimulation/sensing
- Supervised disconnection
- Residual biological/cognitive monitoring
- Non-AI fallback
- Harm repair and appeal
